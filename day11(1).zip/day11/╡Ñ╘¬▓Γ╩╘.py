import unittest
import HTMLTestRunner
from BeautifulReport import BeautifulReport as bf
class TestCalc(unittest.TestCase):
	def setUp(self):
		print('setup是啥时候运行的')
		#每个用例运行之前运行的
	def tearDown(self):
		print('teardown是啥时候运行')
		#每个用例运行之后运行的
	@classmethod
	def setUpClass(cls):
		#在所有用例执行之前运行的
		print('什么时候运行的setupclss')

	@classmethod
	def tearDownClass(cls):
		#在所有用例都执行完之后运行的
		print('什么时候运行的teardownclass')

	def testliuwei(self):
		'''刘伟测试'''
		print('刘伟')
		self.assertEqual(1,1)
	def testzch(self):
		'''赵传慧测试'''
		print('赵传慧')
		self.assertEqual(1,2)
	def testa(self):
		print('testa')
		self.assertEqual(1,1)
	def testc(self):
		print('testc')
		self.assertEqual(1,2)

# 用例集  测试套件
	#存放测试用例的
# unittest.main() #会运行当前python文件里面的所有测试用例
# 1、先把所有的测试用例都放到用例集
#2、运行这些测试用例
#3、产生报告
suite = unittest.TestSuite()  #测试集合
suite.addTest( unittest.makeSuite(TestCalc) ) #把刚才写的用例加进来
run = bf(suite)
run.report(description='描述必须写',filename='test')


# f = open('test.html','wb')
# runner = HTMLTestRunner.HTMLTestRunner(f,title='双鱼座用例标题',description='这是用例描述')
# runner.run(suite) #运行用例