import datetime
import yagmail
from conf import setting
import os
import unittest
from BeautifulReport import BeautifulReport as bf
def makeCase():
	all_yaml = os.listdir(setting.YAML_PATH)
	base_case_str = open(setting.CASE_TEMPLATE,encoding='utf-8').read()#读取到文件里的东西
	for yaml in all_yaml:
		if yaml.endswith('.yaml') or yaml.endswith('.yml'):#判断是否是yml文件
			class_name = yaml.replace('.yml','').replace('.yaml','').capitalize()#获取类名，并首字母大写
			file_name = os.path.join(setting.YAML_PATH,yaml)#拼接绝对路径
			content = base_case_str %(class_name,file_name)
			py_file_name = os.path.join(setting.CASE_PATH,class_name)#拼好python文件的绝对路径
			open('%s.py'%py_file_name,'w',encoding='utf-8').write(content)

def run_all_case():
	suite = unittest.TestSuite()
	all_py = unittest.defaultTestLoader.discover(setting.CASE_PATH,'*.py')
	#找到所有的python文件
	[ suite.addTests(py) for py in all_py]
	#列表生成式，添加文件里面的case到测试集合里面
	run=bf(suite)
	today = datetime.datetime.today().strftime('%Y%m%d%H%M%S')
	title = '%s_接口测报告.html'%today
	report_abs_path = os.path.join(setting.REPORT_PATH,title) #
	run.report(title,filename=title,log_path=setting.REPORT_PATH)
	return run.success_count,run.failure_count,report_abs_path


def sendmail(title,content,attrs=None):
	m = yagmail.SMTP(host=setting.MAIL_HOST,user=setting.MAIL_USER
				 ,password=setting.MAIL_PASSWRD
				 )
	m.send(to=setting.TO,subject=title,
		   contents=content,
		   attachments=attrs)



