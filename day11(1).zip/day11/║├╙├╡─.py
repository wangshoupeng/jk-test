from nnlog import Logger
log = Logger('nhy.log')
log.debug('宇航员')
log.info('xxx')
log.warning('test')
