import yaml

f = open('login.yaml',encoding='utf-8')
res = yaml.load(f)
print(res)
